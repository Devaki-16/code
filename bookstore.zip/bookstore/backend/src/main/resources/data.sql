INSERT INTO book (title, author, price) VALUES
('The Great Gatsby', 'F. Scott Fitzgerald', 10.99),
('To Kill a Mockingbird', 'Harper Lee', 12.50),
('1984', 'George Orwell', 8.99);